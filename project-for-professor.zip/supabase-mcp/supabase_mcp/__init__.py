"""
Supabase MCP Server - A Model Context Protocol server for Supabase database operations.
"""

__version__ = "0.1.0"
