"""
Test package for the Supabase MCP server.
"""
